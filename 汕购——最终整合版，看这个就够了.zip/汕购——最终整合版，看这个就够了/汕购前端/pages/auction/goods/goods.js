Page({
  data: {
    goods: {},
    buyer: {},
    productPrice: '',
    productId: '',
    productName: '',
    productPrice: '',
    productImage: '',
    goods_img: [],
    goods_info: {},
    remainingTime: '', // 存储剩余时间
    highestPrice: '',
    goods_description: '',
    provide_service: true,
    rental_period: '',
    auctionEndTime: '', // 拍卖结束时间
    transactionPrice: '',
    buyer_openid: '',
    timer: null, // 定时器
  },

  onLoad: function (options) {
    const productId = options.query;
    const openid = wx.getStorageSync('openid');
    this.setData({
      productId: productId,
    });
  
    // 获取商品信息
    wx.request({
      url: 'https://101972498yahu.vicp.fun/api/selectgoods/',
      method: 'POST',
      data: {
        product_id: productId,
      },
      success: (res) => {
        if (res.statusCode === 200) {
          const productData = res.data;
          const fullImageUrls = productData.images.map(image => `https://101972498yahu.vicp.fun/media/uploads/${image}`);
  
          this.setData({
            goods_info: productData,
            productName: productData.name,
            productPrice: productData.price,
            goods_img: fullImageUrls,
            productImage: fullImageUrls[0] || '',
            goods_description: productData.description,
            provide_service: productData.provide_service,
            seller_name: productData.seller_name,
          });
  
          if (productData.rental_period !== 0) {
            this.setData({
              rental_period: productData.rental_period,
            });
          }
        } else {
          wx.showToast({
            title: '商品信息加载失败',
            icon: 'none',
          });
        }
      },
      fail: (err) => {
        wx.showToast({
          title: '请求失败，请稍后再试',
          icon: 'none',
        });
      }
    });
    wx.request({
      url: 'https://101972498yahu.vicp.fun/api/addtohistory/',  // 后端接口地址
      method: 'POST',
      data: {
        openid: wx.getStorageSync('openid'),  // 从本地存储获取用户的 openid
        product_id: productId,  // 商品的 product_id，假设你已经定义了该变量
      },
      success: (res) => {
        // 请求成功的回调函数
        if (res.statusCode === 200 && res.data.success) {
          // 处理成功的情况
         console.log("productid:",productId,"已添加到历史记录");
        } else {
          console.log("添加失败");
        }
      },
      fail: (err) => {
        // 请求失败的回调函数
        wx.showToast({
          title: '请求失败，请稍后重试',
          icon: 'none',
          duration: 2000
        });
      }
    });
  
    // 获取拍卖结束时间和当前最高价
    const self = this;
    wx.request({
      url: 'https://101972498yahu.vicp.fun/api/selectauction/',
      method: 'POST',
      data: {
        product_id: self.data.productId
      },
      success(res) {
        if (res.statusCode === 200) {
          const data = res.data;
          if (data && data.transaction_price !== undefined && data.auction_end_time) {
            const auctionEndTime = new Date(data.auction_end_time); // 拍卖结束时间
            const transactionPrice = data.transaction_price;  // 当前交易价格
  
            self.setData({
              transactionPrice: transactionPrice,
              auctionEndTime: auctionEndTime,
            });
  
            // 判断拍卖是否结束
            const currentTime = new Date();
            if (currentTime >= auctionEndTime) {
              // 拍卖已结束，向后端发送请求处理商品
              self.sendAuctionEndRequest(productId);
            } else {
              // 启动倒计时
              self.startCountdown(auctionEndTime);
            }
          } else {
            wx.showToast({
              title: '拍卖信息加载失败',
              icon: 'none',
            });
          }
        } else {
          wx.showToast({
            title: res.data.error || '获取拍卖信息失败',
            icon: 'none',
          });
        }
      },
      fail(error) {
        wx.showToast({
          title: '请求失败，请稍后再试',
          icon: 'none',
        });
      }
    });
  },
  
  // 拍卖结束后向后端发送请求
  sendAuctionEndRequest(productId) {
    wx.request({
      url: 'https://101972498yahu.vicp.fun/api/checkauctionstatus/',
      method: 'POST',
      data: {
        product_id: productId,
      },
      success: (res) => {
        if (res.statusCode === 200 && res.data.success) {
          wx.showToast({
            title: '拍卖已结束，商品已处理',
            icon: 'none',
          });
          setTimeout(() => {
            wx.reLaunch({
              url: '/pages/auction/auction',
            });
          }, 1000);
        } else {
          wx.showToast({
            title: res.data.message || '操作失败',
            icon: 'none',
          });
        }
      },
      fail: (err) => {
        wx.showToast({
          title: '请求失败，请重试',
          icon: 'none',
        });
      }
    });
  },
  

  // 倒计时函数
  startCountdown(auctionEndTime) {
    const self = this;
    // 定时器每秒更新剩余时间
    this.data.timer = setInterval(() => {
      const currentTime = new Date(); // 当前时间
      const timeDifference = auctionEndTime - currentTime; // 剩余时间差

      // 如果时间差小于或等于0，停止倒计时并设置状态
      if (timeDifference <= 0) {
        clearInterval(self.data.timer);
        self.setData({
          remainingTime: '拍卖已结束',
        });
      } else {
        // 格式化倒计时
        const hours = Math.floor(timeDifference / (1000 * 60 * 60));
        const minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeDifference % (1000 * 60)) / 1000);

        self.setData({
          remainingTime: `${hours}：${minutes}：${seconds}`, // 更新剩余时间
        });
      }
    }, 1000);  // 每秒更新一次
  },

  // 页面卸载时清除定时器
  onUnload() {
    if (this.data.timer) {
      clearInterval(this.data.timer); // 清除定时器
    }
  },

  // 预览商品图片
  previewImage: function (e) {
    var current = e.target.dataset.src;
    var goodsImg = this.data.goods_img || [];
    var imgList = goodsImg.map(img => img);

    wx.previewImage({
      current: current,
      urls: imgList,
    });
  },

  // 点击出价
  bid: function () {
    const openid = wx.getStorageSync('openid');
    const currentHighestPrice = this.data.transactionPrice;

    if (!openid) {
      wx.showToast({
        title: '未获取到用户信息，请登录后再试',
        icon: 'none',
      });
      return;
    }

    wx.showModal({
      title: '输入出价',
      editable: true,
      placeholderText: `当前最高价：${currentHighestPrice}，请输入更高的价格`,
      success: (res) => {
        if (res.confirm) {
          const userBid = parseFloat(res.content);
          if (isNaN(userBid) || userBid <= currentHighestPrice) {
            wx.showToast({
              title: '出价过低，请重新出价',
              icon: 'none',
            });
          } else {
            wx.request({
              url: 'https://101972498yahu.vicp.fun/api/bid/',
              method: 'POST',
              data: {
                buyer_openid: openid,
                bid_price: userBid,
                product_id: this.data.productId,
              },
              success: (response) => {
                if (response.data.success) {
                  wx.showToast({
                    title: '出价成功',
                    icon: 'success',
                  });
                  this.setData({
                    transactionPrice: userBid,
                  });
                } else {
                  wx.showToast({
                    title: response.data.message || '出价失败，请重试',
                    icon: 'none',
                  });
                }
              },
              fail: () => {
                wx.showToast({
                  title: '网络错误，请稍后再试',
                  icon: 'none',
                });
              },
            });
          }
        }
      },
    });
  },

  collect() {
    const openid = wx.getStorageSync('openid');
    const product_id = this.data.productId;

    wx.request({
      url: 'https://101972498yahu.vicp.fun/api/addtofavorites/',
      method: 'POST',
      data: {
        openid: openid,
        product_id: product_id
      },
      success: (res) => {
        if (res.data.success) {
          this.setData({
            isFavorited: true
          });
          wx.showToast({
            title: '收藏成功',
            icon: 'success'
          });
        } else {
          wx.showToast({
            title: res.data.message || '操作失败',
            icon: 'none'
          });
        }
      },
      fail: (err) => {
        wx.showToast({
          title: '请求失败，请重试',
          icon: 'none'
        });
      }
    });
  },

  onReady() {},

  onShow() {},

  onHide() {},

  onUnload() {
    if (this.data.timer) {
      clearInterval(this.data.timer); // 清除定时器
    }
  },

  onPullDownRefresh() {},

  onReachBottom() {},

  onShareAppMessage() {}
});
